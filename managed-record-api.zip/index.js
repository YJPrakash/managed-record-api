const express = require('express');
const fetch = require('axios');
const PORT = process.env.PORT || 8080;

const server = express();

const {data}= require('./data');
const recordRoute = require('./routes/records');

server.use('/records', recordRoute);

server.get('/api/managed-records', async (req, res)=>{
    const {query: {currentPage, pageSize}} = req;

    const {data: filterd_data} = await fetch(`http://${req.hostname}:${PORT}/records?currentPage=${currentPage}&pageSize=${pageSize}`);
    // filterd_data.meta.
    res.json({
        Ids: data.map((datas)=> {
            return datas.id;
        }),
        Open: filterd_data.rows.filter((datas)=> datas.disposition == "open"),
        CloseCount: filterd_data.rows.filter((datas)=> datas.disposition == "closed").length,
        PreviousPage: filterd_data.meta.currentPage-1,
        NextPage: filterd_data.meta.currentPage+1
    });
});
server.listen(PORT, '0.0.0.0');
console.log('server started');