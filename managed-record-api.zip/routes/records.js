const {data} = require('../data');
const {Router} = require('express');
const {paginate, calculateLimitAndOffset} = require('paginate-info');

const count = data.length;

const router = new Router();

router.get('/', (req, res)=>{
    if(req.query) {
        const {query: {currentPage, pageSize}} = req;
        // const { limit, offset } = calculateLimitAndOffset(currentPage, 10);
        const { limit, offset } = calculateLimitAndOffset(currentPage, pageSize);
        const rows = data.slice(offset, offset + limit);
        const meta = paginate(currentPage, count, rows);
        // res.json({...meta, offset});
        res.json({rows, meta});
    } else {
        res.json(data);
    }

});

module.exports = router;