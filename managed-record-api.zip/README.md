## Steps( follow npm scripts)

``` 
npm i
npm start
```

## Open browser navigate the below link;

```
http://localhost:3000/api/managed-routes?currentPage=5&pageSize=10

```

## Now you get the expected output

## Fetch request to handle the pagination size. 